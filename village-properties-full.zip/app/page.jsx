export default function Home() {
  return (
    <section>
      <h1 style={{fontSize: '2rem', marginBottom: '1rem'}}>Find your home in Santa Barbara County</h1>
      <p style={{color:'#555'}}>Explore neighborhoods, schools, and listings with Ryan Kell at Village Properties.</p>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:16, marginTop:24}}>
        <img src="/placeholder1.jpg" alt="listing" className="card" style={{width:'100%', height:180, objectFit:'cover'}}/>
        <img src="/placeholder2.jpg" alt="listing" className="card" style={{width:'100%', height:180, objectFit:'cover'}}/>
        <img src="/placeholder3.jpg" alt="listing" className="card" style={{width:'100%', height:180, objectFit:'cover'}}/>
      </div>
    </section>
  )
}
