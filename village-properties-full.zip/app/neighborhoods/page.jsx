export default function Neighborhoods() {
  return (
    <section>
      <h1>Neighborhoods</h1>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:16, marginTop:16}}>
        <div className="card"><img src="/neighborhood1.jpg" alt="neigh" style={{width:'100%', height:160, objectFit:'cover'}}/><div style={{padding:12}}><h3>Santa Barbara</h3></div></div>
        <div className="card"><img src="/neighborhood2.jpg" alt="neigh" style={{width:'100%', height:160, objectFit:'cover'}}/><div style={{padding:12}}><h3>Montecito</h3></div></div>
      </div>
    </section>
  )
}
